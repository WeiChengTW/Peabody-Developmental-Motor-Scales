import cv2
import numpy as np
import glob
import os

def crop_paper(image_path, output_path="cropped.jpg", show_debug=False):
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError("圖片讀取失敗，請確認路徑正確")

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(blur, 50, 150)
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    found = False
    for idx, cnt in enumerate(contours):
        epsilon = 0.02 * cv2.arcLength(cnt, True)
        approx = cv2.approxPolyDP(cnt, epsilon, True)
        print(f"輪廓 {idx}: 頂點數 = {len(approx)}，面積 = {cv2.contourArea(cnt)}")
        if len(approx) == 4:
            paper_contour = cnt
            approx_paper = approx
            found = True
            break

    if not found:
        debug_img = img.copy()
        cv2.drawContours(debug_img, contours, -1, (0,255,0), 2)
        cv2.imshow("All Contours", debug_img)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
        raise ValueError("無法偵測白紙四邊形輪廓")

    pts = approx_paper.reshape(4, 2)
    pts = sorted(pts, key=lambda p: p[0])
    left = sorted(pts[0:2], key=lambda p: p[1])
    right = sorted(pts[2:4], key=lambda p: p[1])
    tl, bl = left
    tr, br = right

    dst_width = int(np.linalg.norm(tr - tl))
    dst_height = int(np.linalg.norm(bl - tl))
    dst_pts = np.array([[0, 0], [dst_width - 1, 0],
                        [dst_width - 1, dst_height - 1], [0, dst_height - 1]], dtype="float32")
    src_pts = np.array([tl, tr, br, bl], dtype="float32")
    M = cv2.getPerspectiveTransform(src_pts, dst_pts)
    warped = cv2.warpPerspective(img, M, (dst_width, dst_height))

    cv2.imwrite(output_path, warped)

    if show_debug:
        debug_img = img.copy()
        cv2.drawContours(debug_img, [approx_paper], -1, (0, 0, 255), 3)
        cv2.imshow("Detected Paper Contour", debug_img)
        cv2.imshow("Cropped Paper", warped)
        cv2.waitKey(0)
        cv2.destroyAllWindows()

if __name__ == "__main__":
    image_folder = "image"  # 讀取 image 資料夾
    output_folder = "new"   # 輸出到 new 資料夾
    os.makedirs(output_folder, exist_ok=True)

    image_files = sorted(
        glob.glob(os.path.join(image_folder, "*.jpg")) +
        glob.glob(os.path.join(image_folder, "*.png"))
    )

    for idx, img_path in enumerate(image_files, start=1):
        output_path = os.path.join(output_folder, f"new{idx}.jpg")
        try:
            crop_paper(img_path, output_path, show_debug=False)  # show_debug 設 False 批量裁切才不會一直跳視窗
            print(f"{img_path} → 已裁切儲存到 {output_path}")
        except Exception as e:
            print(f"{img_path} → {e}")
