import cv2
import numpy as np
import os
import glob

# === 讀取 new 資料夾全部 JPG ===
new_folder = "new"
img_paths = sorted(glob.glob(os.path.join(new_folder, "*.jpg")))

# === 你原本的黑點偵測（未改邏輯） ===
def detect_dots(gray):
    H, W = gray.shape
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    g = clahe.apply(gray)
    g = cv2.GaussianBlur(g, (5, 5), 0)
    se = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (31, 31))
    bh = cv2.morphologyEx(g, cv2.MORPH_BLACKHAT, se)

    _, bwA = cv2.threshold(bh, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    bwA = cv2.morphologyEx(bwA, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8), iterations=2)
    bwA = cv2.morphologyEx(bwA, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8), iterations=2)

    def pick_from_binary(bw, area_min=100, area_max=9000, circ_th=0.58, ar_th=1.5):
        dots_local = []
        contours, _ = cv2.findContours(bw, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if not (area_min <= area <= area_max): continue
            peri = cv2.arcLength(cnt, True)
            if peri == 0: continue
            circularity = 4 * np.pi * area / (peri ** 2)
            if circularity < circ_th: continue
            (w1, h1) = cv2.minAreaRect(cnt)[1]
            if min(w1, h1) == 0: continue
            ar = max(w1, h1) / min(w1, h1)
            if ar > ar_th: continue
            M = cv2.moments(cnt)
            if M["m00"] <= 0: continue
            cx = int(M["m10"] / M["m00"])
            cy = int(M["m01"] / M["m00"])
            dots_local.append((cx, cy, area))
        return sorted(dots_local, key=lambda d: -d[2])[:2]

    dots = pick_from_binary(bwA)
    if len(dots) >= 2:
        return dots, bwA

    inv = cv2.bitwise_not(gray)
    bwB = cv2.adaptiveThreshold(inv, 255, cv2.ADAPTIVE_THRESH_MEAN_C,
                                cv2.THRESH_BINARY, 31, 5)
    bwB = cv2.morphologyEx(bwB, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8), iterations=1)
    bwB = cv2.morphologyEx(bwB, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8), iterations=2)

    dots = pick_from_binary(bwB, area_min=80, area_max=12000, circ_th=0.52, ar_th=1.6)
    if len(dots) >= 2:
        return dots, bwB

    blur = cv2.medianBlur(gray, 5)
    circles = cv2.HoughCircles(
        blur, cv2.HOUGH_GRADIENT, dp=1.2, minDist=max(40, W//6),
        param1=100, param2=14, minRadius=6, maxRadius=40
    )
    bwC = np.zeros_like(gray, dtype=np.uint8)
    dots = []
    if circles is not None:
        circles = np.uint16(np.around(circles[0]))
        circles = sorted(circles, key=lambda c: -c[2])[:2]
        for (x, y, r) in circles:
            cv2.circle(bwC, (x, y), r, 255, -1)
            dots.append((int(x), int(y), int(np.pi * r * r)))
        if len(dots) >= 2:
            return dots, bwC

    return [], bwC if np.count_nonzero(bwC) > 0 else bwB if np.count_nonzero(bwB) > 0 else bwA

# === 幾何距離 ===
def point_line_dist(px, py, x1, y1, x2, y2):
    A = np.array([x2 - x1, y2 - y1], dtype=float)
    B = np.array([px - x1, py - y1], dtype=float)
    L = np.linalg.norm(A)
    if L < 1e-6:
        return np.linalg.norm(B), (x1, y1), 0.0

    # 投影係數（不夾）
    t_raw = float(np.dot(A, B) / (L * L))
    proj = np.array([x1, y1], dtype=float) + t_raw * A

    # 垂直距離（到無限延長線的真正垂距）
    # |A x B| / |A|
    cross = abs(A[0] * B[1] - A[1] * B[0])
    d_perp = cross / L
    return d_perp, tuple(proj.astype(int)), t_raw


# === 新增：判斷線是否碰到兩點 + 是否同一條線 ===
def touch_and_connect(line_mask_raw, p1, p2, touch_r=6, bridge_dilate=3):
    def touching(p):
        m = np.zeros_like(line_mask_raw)
        cv2.circle(m, p, touch_r, 255, -1)
        return cv2.countNonZero(cv2.bitwise_and(line_mask_raw, m)) > 0
    t1 = touching(p1)
    t2 = touching(p2)
    tmp = cv2.dilate(line_mask_raw, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (bridge_dilate, bridge_dilate)), 1)
    cv2.circle(tmp, p1, touch_r, 255, -1)
    cv2.circle(tmp, p2, touch_r, 255, -1)
    _, labels = cv2.connectedComponents(tmp)
    id1 = labels[p1[1], p1[0]]
    id2 = labels[p2[1], p2[0]]
    conn = (id1 != 0) and (id1 == id2)
    return t1, t2, conn

# === 新增：評分規則 ===
def score_by_rule(connectable, deviation_cm):
    if not connectable: return 0, "Can't connect"
    if deviation_cm <= 0.65: return 2, "Connect and offset <= 0.65 cm"
    if deviation_cm <= 1.25: return 1, "Connect offset between 0.65 and 1.25 cm"
    return 0, "Connect but offset > 1.25 cm"

# === 統一縮小顯示視窗（保留你原本四個視窗的呈現） ===
def show_scaled(title, img, max_width=500):
    h, w = img.shape[:2]
    if w > max_width:
        scale = max_width / w
        img = cv2.resize(img, (int(w*scale), int(h*scale)), interpolation=cv2.INTER_AREA)
    cv2.namedWindow(title, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(title, img.shape[1], img.shape[0])
    cv2.imshow(title, img)

# === 逐張處理，並保留你原本要顯示的四個視窗 ===
for path in img_paths:
    img = cv2.imread(path)
    if img is None:
        print(f"無法讀取：{path}")
        continue

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    img_color = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)

    # -- 黑點偵測 + 除錯視圖（保留 All Dot Contours） --
    dots, dot_bw_debug = detect_dots(gray)
    dot_points = [(x, y) for x, y, _ in dots]
    contour_viz = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    contours_dbg, _ = cv2.findContours(dot_bw_debug, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    colors = [(0,0,255), (0,255,0), (255,0,0), (0,255,255), (255,0,255), (255,255,0)]
    for i, c in enumerate(contours_dbg):
        cv2.drawContours(contour_viz, [c], -1, colors[i % len(colors)], 2)

    # -- Dot Mask（保留） --
    dot_mask_clean = np.zeros_like(gray, dtype=np.uint8)
    for x, y in dot_points:
        cv2.circle(dot_mask_clean, (x, y), 13, 255, -1)

    # -- 線條 mask（保留） --
    adaptive_mask = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 31, 15
    )
    kernel2 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    adaptive_mask = cv2.morphologyEx(adaptive_mask, cv2.MORPH_OPEN, kernel2, iterations=1)
    adaptive_mask = cv2.dilate(adaptive_mask, kernel2, iterations=1)

    contours2, _ = cv2.findContours(adaptive_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    h, w = adaptive_mask.shape
    possible_curves = []
    for cnt in contours2:
        x, y, w_box, h_box = cv2.boundingRect(cnt)
        if y > h // 2:  # 你的原條件
            continue
        if cv2.contourArea(cnt) < 50:
            continue
        possible_curves.append(cnt)

    # -- 同步建立 raw / clean 兩份遮罩（關鍵：保留 Black Line Mask 的呈現） --
    black_line_mask_clean = np.zeros_like(adaptive_mask)  # 你的原視窗會用到
    black_line_mask_raw   = np.zeros_like(adaptive_mask)  # 新增：不挖點，用於觸點/連通判斷
    max_curve = max(possible_curves, key=cv2.contourArea) if possible_curves else None
    if max_curve is not None:
        # 原始線條（raw，不挖點）
        cv2.drawContours(black_line_mask_raw, [max_curve], -1, 255, -1)
        # 乾淨線條（clean，挖掉點）
        cv2.drawContours(black_line_mask_clean, [max_curve], -1, 255, -1)
        contours_dot, _ = cv2.findContours(dot_mask_clean, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(black_line_mask_clean, contours_dot, -1, 0, -1)
        for x, y in dot_points:
            cv2.circle(black_line_mask_clean, (x, y), 20, 0, -1)

    # -- 若黑點不足 2 個：照舊顯示三個視窗，然後處理下一張（原本是 exit；改成 continue 以便批次） --
    if len(dot_points) != 2:
        print(f"{os.path.basename(path)}：只找到 {len(dot_points)} 個黑點，請確認標記品質！")
        show_scaled("Dot Mask", dot_mask_clean, 500)
        show_scaled("Black Line Mask", black_line_mask_clean, 500)
        show_scaled("All Dot Contours", contour_viz, 500)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
        continue

    # -- 比例尺（兩點 = 10cm） --
    (x1, y1), (x2, y2) = dot_points
    dist_pixel = np.linalg.norm(np.array([x1, y1]) - np.array([x2, y2]))
    pixel_per_cm = dist_pixel / 10.0
    if pixel_per_cm < 15 or pixel_per_cm > 100:
        print(f"{os.path.basename(path)}：比例尺異常，請檢查黑點距離（{pixel_per_cm:.2f} px/cm）")

    # -- 偏差距離（曲線至端點直線最大垂距） --
    max_dist = 0.0
    max_curve_pt, proj_pt = None, None
    valid_found = False

    if max_curve is not None:
        for pt in max_curve.reshape(-1, 2):
            d_perp, proj, t_raw = point_line_dist(pt[0], pt[1], x1, y1, x2, y2)
            # 只量線段中間的垂距，避免端點外側被夾到端點
            if 0.0 < t_raw < 1.0:
                valid_found = True
                if d_perp > max_dist:
                    max_dist = d_perp
                    max_curve_pt = (int(pt[0]), int(pt[1]))
                    proj_pt = proj

        # 如果沒有任何點的投影在 0~1（很少發生），退回舊邏輯：把 t 夾 0~1 再算
        if not valid_found:
            for pt in max_curve.reshape(-1, 2):
                # 舊邏輯：夾 t 再算距離
                A = np.array([x2 - x1, y2 - y1], dtype=float)
                B = np.array([pt[0] - x1, pt[1] - y1], dtype=float)
                L = np.linalg.norm(A)
                if L < 1e-6:
                    continue
                t = np.clip(np.dot(A, B) / (L * L), 0.0, 1.0)
                proj = np.array([x1, y1], dtype=float) + t * A
                d = np.linalg.norm(np.array([pt[0], pt[1]], dtype=float) - proj)
                if d > max_dist:
                    max_dist = d
                    max_curve_pt = (int(pt[0]), int(pt[1]))
                    proj_pt = tuple(proj.astype(int))

    deviation_cm = (max_dist / pixel_per_cm) if (max_dist > 0 and pixel_per_cm > 1e-6) else float("inf")

    # -- 是否真的接到兩點 + 是否同一條線 --
    p1, p2 = (x1, y1), (x2, y2)
    touch1, touch2, same_component = touch_and_connect(black_line_mask_raw, p1, p2, touch_r=6, bridge_dilate=3)

    connectable = (touch1 and touch2 and same_component)

    # 不可連線：直接 0 分，且不計偏差
    if not connectable:
        score, reason = 0, "Can't connect"
        deviation_cm = None          # 用 None 代表「不計」
    else:
        # 可連線才計偏差（保留你原本的偏差計算：外輪廓或骨架版都可）
        # ---- 你的偏差計算區塊（max_dist、max_curve_pt、proj_pt、deviation_cm）----
        # deviation_cm = (max_dist / pixel_per_cm) if (...) else float("inf")

        score, reason = score_by_rule(True, deviation_cm)


    # -- 視覺化主圖（Black Dot Detection 視窗用） --
    img_disp = img_color.copy()
    for idx, (x, y) in enumerate(dot_points):
        cv2.circle(img_disp, (x, y), 7, (0, 0, 255), -1)
        cv2.putText(img_disp, f"dot{idx+1}", (x+8, y-8), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,0,0), 2)
    cv2.line(img_disp, dot_points[0], dot_points[1], (0,0,255), 2)

    # 觸點顯示（保留與增強）
    for idx, (x, y) in enumerate(dot_points):
        ok = touch1 if idx == 0 else touch2
        c = (255, 0, 0) if ok else (0, 0, 255)
        cv2.circle(img_disp, (x, y), 10, c, 2)
        cv2.putText(img_disp, f"touch{idx+1}:{'Yes' if ok else 'No'}", (x+12, y+18),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, c, 2)

    # 偏差線段與文字（只有可連線且有有效偏差才畫）
    if (deviation_cm is not None) and max_curve_pt and proj_pt and np.isfinite(deviation_cm):
        cv2.circle(img_disp, max_curve_pt, 7, (0,255,255), -1)
        cv2.circle(img_disp, proj_pt, 7, (0,255,255), -1)
        cv2.line(img_disp, max_curve_pt, proj_pt, (0,255,255), 2)
        mid_x = int((max_curve_pt[0] + proj_pt[0]) / 2)
        mid_y = int((max_curve_pt[1] + proj_pt[1]) / 2)
        cv2.putText(img_disp, f"{deviation_cm:.2f} cm",
                    (mid_x+10, mid_y), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0,255,255), 2)
    else:
        # 不可連線或偏差無效就不畫黃線，可選擇顯示 N/A 提示
        cv2.putText(img_disp, "deviation: No (not connected)",
                    (30, 160), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,0,255), 2)


    # pixel/cm、same_component、Score（保留＋新增）
    cv2.putText(img_disp, f"pixel/cm: {pixel_per_cm:.2f}", (30, 40),
                cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0,0,255), 2)
    cv2.putText(img_disp, f"same_component: {'Yes' if same_component else 'No'}",
                (30, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (250, 0, 255), 2)
    score_color = (0, 180, 0) if score == 2 else ((0, 165, 255) if score == 1 else (0, 0, 255))
    cv2.putText(img_disp, f"Score: {score} ({reason})", (30, 80),
                cv2.FONT_HERSHEY_SIMPLEX, 1.0, score_color, 2)

    # === 保留你原本四個視窗的顯示 ===
    show_scaled("Dot Mask", dot_mask_clean, 500)
    show_scaled("Black Line Mask", black_line_mask_clean, 500)
    show_scaled("All Dot Contours", contour_viz, 500)
    show_scaled("Black Dot Detection", img_disp, 800)

    dev_str = "{:.3f}".format(deviation_cm) if (deviation_cm is not None and np.isfinite(deviation_cm)) else "N/A"
    print(f"{os.path.basename(path)} → score={score}, deviation={dev_str} cm, "
        f"touch=({touch1},{touch2}), same={same_component}")

    print(f"得分：{score}")

    # 等待與關閉（每張圖一次）
    cv2.waitKey(0)
    cv2.destroyAllWindows()
