# quadrilateral > 2025-09-03 3:47pm
https://universe.roboflow.com/uuriglass/quadrilateral-gu4av

Provided by a Roboflow user
License: CC BY 4.0

